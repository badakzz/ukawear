<?php return array (
  'parameters' => 
  array (
    'database_host' => 'ukawearcvtuka2.mysql.db',
    'database_port' => '',
    'database_name' => 'ukawearcvtuka2',
    'database_user' => 'ukawearcvtuka2',
    'database_password' => 'd46QLh1JafkusBY6Dfc6',
    'database_prefix' => 'ps_',
    'database_engine' => 'InnoDB',
    'mailer_transport' => 'smtp',
    'mailer_host' => '127.0.0.1',
    'mailer_user' => NULL,
    'mailer_password' => NULL,
    'secret' => 'V4Xitfxd2nYIIkEHOFhw3QH2qv5xIDc8g60UWqI8qIYoLjtDszm0iHVK',
    'ps_caching' => 'CacheMemcache',
    'ps_cache_enable' => false,
    'ps_creation_date' => '2018-10-09',
    'locale' => 'fr-FR',
    'cookie_key' => '4PakkIiArvs996wQgffWS9CasuRDGgWBUtmuVMyJfiU7jhGwFRvq3eDZ',
    'cookie_iv' => 'y5cErVjo',
    'new_cookie_key' => 'def0000068460b75b0d49476c7861a6ebcc68d446b9dae1c63d334284e31a0c9f59f05c85a694c06254e5c764251bd3188270041a3668ca48de467643d62041ca6ab1d57',
  ),
);
